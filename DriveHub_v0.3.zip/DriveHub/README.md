# DriveHub – private Android Auto dashboard (v0.3)

One dashboard on the Android Auto screen with 6 tiles: **Maps · YouTube (browser) · YouTube Music · WhatsApp · Teams · Pocket Casts**.
Tap a tile to zoom into it. YouTube runs in a real web browser on the car screen with **no playback lock** (passenger-facing screen).

## 1. Build on GitHub
1. Create a new **private** repo on github.com.
2. Upload **all** files from this zip (keep the folder structure).
   - Check that `.github/workflows/build.yml` exists in the repo. Some browsers skip folders starting with a dot –
     if it is missing: **Add file → Create new file**, name it `.github/workflows/build.yml` and paste the content.
3. Open the **Actions** tab → *Build DriveHub APK* → it runs on every push (or **Run workflow**).
4. When it's green: open the run → **Artifacts** → download **DriveHub-apk** (zip with `app-debug.apk`).

All builds are signed with the same key (`app/drivehub.keystore`), so new versions install over old ones.

## 2. Install on the Pixel 10a (no root)
Android Auto ignores apps that weren't installed from Play, so install through **UnknownAuto** (free, open source):
1. Install UnknownAuto, give it the APK → it installs DriveHub marked as "from Play".
2. Android Auto settings → tap **Version** 10× → ⋮ → **Developer settings** → enable **Unknown sources**.
3. Android Auto settings → **Customise launcher** → make sure **DriveHub** is ticked.

## 3. First run on the phone
Open **DriveHub** on the phone:
1. **Allow notification access** (WhatsApp, Teams, Maps guidance, music controls).
   If the switch is greyed out: App info → ⋮ → **Allow restricted settings**, then try again.
2. **Allow calendar** (next Teams meeting + dial-in).
3. **Open YouTube browser** and sign in once – the car screen uses the same login.
4. Fill favourites, Home / Work / Studio addresses, quick replies → **Save**.

## 4. In the car
| Tile | What it does |
|---|---|
| Maps | Live next-turn from Google Maps; Home/Work/Studio hand off to Google Maps navigation |
| YouTube | m.youtube.com full screen. Top: Back · Play/Pause · Enlarge · Search. Right: Pan (scroll by drag) · ▲ · ▼ · Home. Taps on the page go to YouTube |
| YouTube Music / Pocket Casts | Now playing, play/pause, prev/next, queue / Up Next (tap to jump) |
| WhatsApp | Recent chats + favourites → one-tap quick replies |
| Teams | Next meetings from the calendar; tap = join by phone dial-in; recent Teams notifications |

## Known limits (honest list)
- Tapping inside the YouTube page needs a newer Android Auto (car API 5+). If taps don't register, use Search, ▲/▼ and Play/Pause.
- The real WhatsApp/Teams/Maps apps can't be embedded inside the tiles – DriveHub shows their data and acts on it.
- Pocket Casts "new releases" = its Up Next/queue as exposed by the app.
- Android Auto may still apply its own restrictions while driving; DriveHub itself adds none.
