package com.ori.drivehub

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.CalendarContract
import androidx.core.content.ContextCompat

object CalendarRepo {
    data class Meeting(val title: String, val begin: Long, val end: Long, val isTeams: Boolean, val dial: Uri?)

    fun hasPermission(c: Context) =
        ContextCompat.checkSelfPermission(c, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED

    fun upcoming(c: Context, max: Int = 5): List<Meeting> {
        if (!hasPermission(c)) return emptyList()
        val now = System.currentTimeMillis()
        val builder = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(builder, now - 60 * 60 * 1000L)
        ContentUris.appendId(builder, now + 36 * 60 * 60 * 1000L)
        val proj = arrayOf(
            CalendarContract.Instances.TITLE,
            CalendarContract.Instances.BEGIN,
            CalendarContract.Instances.END,
            CalendarContract.Instances.DESCRIPTION,
            CalendarContract.Instances.EVENT_LOCATION,
            CalendarContract.Instances.ALL_DAY
        )
        val out = ArrayList<Meeting>()
        try {
            c.contentResolver.query(builder.build(), proj, null, null,
                CalendarContract.Instances.BEGIN + " ASC")?.use { cur ->
                while (cur.moveToNext() && out.size < max) {
                    if (cur.getInt(5) == 1) continue
                    val end = cur.getLong(2)
                    if (end < now) continue
                    val desc = (cur.getString(3) ?: "") + "\n" + (cur.getString(4) ?: "")
                    out.add(Meeting(
                        title = cur.getString(0)?.ifBlank { null } ?: "(no title)",
                        begin = cur.getLong(1),
                        end = end,
                        isTeams = desc.contains("teams.microsoft.com", true) ||
                            desc.contains("Microsoft Teams", true),
                        dial = dialIn(desc)
                    ))
                }
            }
        } catch (_: Exception) { }
        return out
    }

    /** Teams invites usually contain "+972 3-XXX..." and "Phone conference ID: 123 456 789#". */
    private fun dialIn(desc: String): Uri? {
        val phone = Regex("""\+\d[\d \-()]{7,}\d""").find(desc)?.value
            ?.replace(Regex("[^+\\d]"), "") ?: return null
        val conf = Regex("""conference ID\s*:?\s*([\d ]+)#""", RegexOption.IGNORE_CASE)
            .find(desc)?.groupValues?.get(1)?.replace(" ", "")
        return Uri.parse("tel:" + phone + if (conf != null) ",,$conf%23" else "")
    }
}
