package com.ori.drivehub.car

import android.content.Intent
import android.net.Uri
import androidx.car.app.CarContext
import androidx.car.app.model.Template
import com.ori.drivehub.DataHub
import com.ori.drivehub.Prefs

/** Live turn-by-turn from Google Maps + one-tap destinations that hand off to Google Maps. */
class MapsScreen(carContext: CarContext) : LiveScreen(carContext) {

    private fun navigate(address: String) {
        try {
            carContext.startCarApp(Intent(CarContext.ACTION_NAVIGATE,
                Uri.parse("geo:0,0?q=" + Uri.encode(address))))
        } catch (e: Exception) { carContext.toast("Could not start navigation") }
    }

    override fun onGetTemplate(): Template {
        val guidance = DataHub.navTitle?.let { listOf(row(it, DataHub.navText)) } ?: emptyList()

        val dest = listOf(
            "🏠 Home" to Prefs.get(carContext, Prefs.HOME),
            "💼 Work" to Prefs.get(carContext, Prefs.WORK),
            "🏺 Studio" to Prefs.get(carContext, Prefs.STUDIO)
        ).map { (label, addr) ->
            if (addr.isBlank()) row(label, "Set the address in DriveHub on the phone")
            else row(label, addr) { navigate(addr) }
        }

        return sectionedList("Maps",
            listOf("Now navigating" to guidance, "Go to" to dest),
            "No destinations")
    }
}
