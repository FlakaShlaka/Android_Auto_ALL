package com.ori.drivehub.car

import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.model.Template
import com.ori.drivehub.DataHub
import com.ori.drivehub.Prefs

/** Recent WhatsApp messages + favourite contacts with one-tap quick replies. */
class WhatsAppScreen(carContext: CarContext) : LiveScreen(carContext) {

    override fun onGetTemplate(): Template {
        val max = carContext.listLimit()
        val chats = DataHub.recentChats()

        val recent = chats.take(max).map { chat ->
            row(chat.name, chat.text) { open(chat) }
        }

        val favs = Prefs.favourites(carContext).take(max).map { name ->
            val chat = chats.firstOrNull { it.name.contains(name, ignoreCase = true) }
            row("★ $name", chat?.text ?: "No open chat yet") {
                if (chat != null) open(chat)
                else carContext.toast("Say \"Hey Google, send a WhatsApp to $name\"")
            }
        }

        return sectionedList("WhatsApp",
            listOf("Recent" to recent, "Favourites" to favs),
            "No messages yet. Make sure notification access is on.")
    }

    private fun open(chat: DataHub.Chat) {
        if (chat.reply == null) carContext.toast("This chat has no reply option")
        else screenManager.push(ReplyScreen(carContext, chat))
    }
}

class ReplyScreen(carContext: CarContext, private val chat: DataHub.Chat) : Screen(carContext) {

    override fun onGetTemplate(): Template {
        val replies = Prefs.quickReplies(carContext).take(carContext.listLimit()).map { text ->
            row(text) { send(text) }
        }
        return sectionedList("Reply to ${chat.name}", listOf(chat.text.take(60) to replies), "No quick replies")
    }

    private fun send(text: String) {
        val action = chat.reply ?: return
        try {
            val inputs = action.remoteInputs ?: return
            val results = Bundle()
            inputs.forEach { results.putCharSequence(it.resultKey, text) }
            val intent = Intent()
            RemoteInput.addResultsToIntent(inputs, intent, results)
            action.actionIntent.send(carContext, 0, intent)
            carContext.toast("Sent to ${chat.name}")
            screenManager.pop()
        } catch (e: Exception) {
            carContext.toast("Could not send – open WhatsApp on the phone")
        }
    }
}
