package com.ori.drivehub.car

import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.ItemList
import androidx.car.app.model.ListTemplate
import androidx.car.app.model.Row
import androidx.car.app.model.SectionedItemList
import androidx.car.app.model.Template

/** Builds a ListTemplate from named sections; empty sections are skipped safely. */
fun sectionedList(
    title: String,
    sections: List<Pair<String, List<Row>>>,
    emptyMessage: String,
    strip: ActionStrip? = null
): Template {
    val b = ListTemplate.Builder().setTitle(title).setHeaderAction(Action.BACK)
    val filled = sections.filter { it.second.isNotEmpty() }
    if (filled.isEmpty()) {
        b.setSingleList(ItemList.Builder().setNoItemsMessage(emptyMessage).build())
    } else if (filled.size == 1 && filled[0].first.isEmpty()) {
        b.setSingleList(ItemList.Builder().apply { filled[0].second.forEach { addItem(it) } }.build())
    } else {
        filled.forEach { (header, rows) ->
            val list = ItemList.Builder().apply { rows.forEach { addItem(it) } }.build()
            b.addSectionedList(SectionedItemList.create(list, header.ifEmpty { " " }))
        }
    }
    strip?.let { b.setActionStrip(it) }
    return b.build()
}

fun row(title: String, text: String? = null, onClick: (() -> Unit)? = null): Row {
    val r = Row.Builder().setTitle(title.ifBlank { "—" })
    if (!text.isNullOrBlank()) r.addText(text.take(120))
    if (onClick != null) r.setOnClickListener(onClick)
    return r.build()
}
