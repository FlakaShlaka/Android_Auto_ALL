package com.ori.drivehub.car

import androidx.car.app.CarContext
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.Template
import com.ori.drivehub.DataHub

/** Now playing + queue / Up Next for YouTube Music or Pocket Casts, with transport controls. */
class MediaScreen(carContext: CarContext, private val pkg: String, private val label: String) :
    LiveScreen(carContext) {

    override fun onGetTemplate(): Template {
        val c = DataHub.controller(pkg)
        if (c == null) {
            return sectionedList(label, emptyList(),
                "Start $label once (phone or Android Auto launcher) – its controls and queue appear here.")
        }
        val tc = c.transportControls
        val playing = DataHub.isPlaying(pkg)

        val now = listOf(row(
            (if (playing) "▶ " else "⏸ ") + (DataHub.nowPlaying(pkg) ?: "Nothing loaded"),
            if (playing) "Tap to pause" else "Tap to play"
        ) { if (DataHub.isPlaying(pkg)) tc.pause() else tc.play() })

        val max = (carContext.listLimit() - 1).coerceAtLeast(1)
        val queue = (c.queue ?: emptyList()).take(max).map { q ->
            row(q.description.title?.toString() ?: "Item",
                q.description.subtitle?.toString()) { tc.skipToQueueItem(q.queueId) }
        }

        val strip = ActionStrip.Builder()
            .addAction(Action.Builder().setTitle("⏮").setOnClickListener { tc.skipToPrevious() }.build())
            .addAction(Action.Builder().setTitle("⏭").setOnClickListener { tc.skipToNext() }.build())
            .build()

        return sectionedList(label,
            listOf("Now playing" to now, (if (label.contains("Pocket")) "Up Next" else "Queue") to queue),
            "Nothing playing", strip)
    }
}
