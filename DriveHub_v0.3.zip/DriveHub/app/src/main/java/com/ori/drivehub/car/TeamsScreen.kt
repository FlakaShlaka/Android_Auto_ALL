package com.ori.drivehub.car

import android.content.Intent
import androidx.car.app.CarContext
import androidx.car.app.model.Template
import com.ori.drivehub.CalendarRepo
import com.ori.drivehub.DataHub
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Next meetings from the phone calendar + recent Teams notifications. Dial-in joins by phone audio. */
class TeamsScreen(carContext: CarContext) : LiveScreen(carContext) {

    override fun onGetTemplate(): Template {
        val fmt = SimpleDateFormat("EEE HH:mm", Locale.getDefault())
        val hm = SimpleDateFormat("HH:mm", Locale.getDefault())
        val max = carContext.listLimit()

        val meetings = if (!CalendarRepo.hasPermission(carContext)) {
            listOf(row("Calendar not allowed", "Open DriveHub on the phone → Allow calendar"))
        } else CalendarRepo.upcoming(carContext, max).map { m ->
            val sub = "${fmt.format(Date(m.begin))}–${hm.format(Date(m.end))}" +
                (if (m.isTeams) " · Teams" else "") +
                (if (m.dial != null) " · tap to join by phone" else "")
            row(m.title, sub) {
                if (m.dial == null) carContext.toast("No dial-in number in this invite")
                else try {
                    carContext.startCarApp(Intent(CarContext.ACTION_DIAL, m.dial))
                } catch (e: Exception) { carContext.toast("Could not dial") }
            }
        }

        val notes = DataHub.teams.take(max).map { row(it.name, it.text) }

        return sectionedList("Teams",
            listOf("Next meetings" to meetings, "Teams notifications" to notes),
            "No upcoming meetings")
    }
}
