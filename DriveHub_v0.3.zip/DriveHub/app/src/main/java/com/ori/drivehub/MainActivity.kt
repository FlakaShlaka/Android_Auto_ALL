package com.ori.drivehub

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat

/** Phone-side setup screen. The real dashboard lives on the Android Auto screen. */
class MainActivity : Activity() {

    private lateinit var status: TextView
    private val fields = LinkedHashMap<String, EditText>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(Color.parseColor("#121417"))
        }
        fun label(t: String, size: Float = 14f, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = size; setTextColor(Color.parseColor("#E8EAED"))
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, pad / 2, 0, pad / 4)
        }.also { root.addView(it) }
        fun button(t: String, onClick: (View) -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; setOnClickListener(onClick)
        }.also { root.addView(it) }
        fun field(key: String, hint: String, def: String = "") {
            val e = EditText(this).apply {
                this.hint = hint
                setText(Prefs.get(this@MainActivity, key, def))
                setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
                inputType = InputType.TYPE_CLASS_TEXT
            }
            fields[key] = e
            root.addView(e)
        }

        label("DriveHub", 26f, true)
        label("Setup on the phone · the dashboard opens on Android Auto")
        status = label("")

        label("1 · Permissions", 18f, true)
        button("Allow notification access (WhatsApp, Teams, Maps, music)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        button("If access is greyed out: App info → ⋮ → Allow restricted settings") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:$packageName")))
        }
        button("Allow calendar (next Teams meeting)") {
            requestPermissions(arrayOf(Manifest.permission.READ_CALENDAR), 1)
        }

        label("2 · YouTube sign-in", 18f, true)
        button("Open YouTube browser (sign in once, it carries to the car)") {
            startActivity(Intent(this, BrowserActivity::class.java))
        }

        label("3 · Personal settings", 18f, true)
        field(Prefs.FAVOURITES, "WhatsApp favourites, comma separated (e.g. Dana, Mom)")
        field(Prefs.HOME, "Home address")
        field(Prefs.WORK, "Work address")
        field(Prefs.STUDIO, "Studio / 3rd destination address")
        field(Prefs.QUICK_REPLIES, "Quick replies separated by |", Prefs.DEFAULT_REPLIES)
        button("Save") {
            fields.forEach { (k, e) -> Prefs.set(this, k, e.text.toString()) }
            DataHub.changed()
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        val nl = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        val cal = CalendarRepo.hasPermission(this)
        status.text = "Notification access: ${if (nl) "✅" else "❌"}    Calendar: ${if (cal) "✅" else "❌"}"
    }
}
