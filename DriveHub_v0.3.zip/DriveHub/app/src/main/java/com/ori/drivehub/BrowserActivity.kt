package com.ori.drivehub

import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient

/** Phone-side YouTube browser. Sign in here once – cookies are shared with the car screen. */
class BrowserActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        WebSetup.configure(web)
        web.webViewClient = WebViewClient()
        setContentView(web)
        web.loadUrl(WebSetup.YT_HOME)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
