package com.ori.drivehub

import android.app.Notification
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper

/** Packages DriveHub reads from. */
object Pk {
    const val WHATSAPP = "com.whatsapp"
    const val WHATSAPP_BIZ = "com.whatsapp.w4b"
    const val TEAMS = "com.microsoft.teams"
    const val MAPS = "com.google.android.apps.maps"
    const val YT_MUSIC = "com.google.android.apps.youtube.music"
    const val POCKET_CASTS = "au.com.shiftyjelly.pocketcasts"
}

/** In-memory live data shared between the notification listener and the car screens. */
object DataHub {
    data class Chat(
        val name: String,
        val text: String,
        val time: Long,
        val reply: Notification.Action?
    )

    /** WhatsApp chats, newest first, keyed by chat name. */
    val whatsapp = LinkedHashMap<String, Chat>()
    val teams = ArrayList<Chat>()
    var navTitle: String? = null
    var navText: String? = null
    var controllers: List<MediaController> = emptyList()

    private val main = Handler(Looper.getMainLooper())
    private val listeners = LinkedHashSet<() -> Unit>()

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }
    fun changed() = main.post { listeners.toList().forEach { it() } }

    fun putWhatsApp(chat: Chat) {
        whatsapp.remove(chat.name)
        val copy = LinkedHashMap<String, Chat>()
        copy[chat.name] = chat
        copy.putAll(whatsapp)
        whatsapp.clear()
        copy.entries.take(20).forEach { whatsapp[it.key] = it.value }
    }

    fun putTeams(chat: Chat) {
        teams.removeAll { it.name == chat.name && it.text == chat.text }
        teams.add(0, chat)
        while (teams.size > 10) teams.removeAt(teams.size - 1)
    }

    fun recentChats(): List<Chat> = whatsapp.values.toList()

    fun controller(pkg: String): MediaController? =
        controllers.firstOrNull { it.packageName == pkg }

    fun nowPlaying(pkg: String): String? {
        val m = controller(pkg)?.metadata ?: return null
        val title = m.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return null
        val artist = m.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: m.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""
        return if (artist.isBlank()) title else "$title · $artist"
    }

    fun isPlaying(pkg: String): Boolean =
        controller(pkg)?.playbackState?.state == PlaybackState.STATE_PLAYING
}
