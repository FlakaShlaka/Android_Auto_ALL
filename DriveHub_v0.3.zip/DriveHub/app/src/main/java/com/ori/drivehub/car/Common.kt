package com.ori.drivehub.car

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.car.app.CarContext
import androidx.car.app.CarToast
import androidx.car.app.Screen
import androidx.car.app.constraints.ConstraintManager
import androidx.car.app.model.CarIcon
import androidx.core.graphics.drawable.IconCompat
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.ori.drivehub.DataHub

fun CarContext.icon(res: Int): CarIcon =
    CarIcon.Builder(IconCompat.createWithResource(this, res)).build()

fun CarContext.toast(msg: String) = CarToast.makeText(this, msg, CarToast.LENGTH_SHORT).show()

fun CarContext.listLimit(): Int = try {
    getCarService(ConstraintManager::class.java)
        .getContentLimit(ConstraintManager.CONTENT_LIMIT_TYPE_LIST)
} catch (_: Exception) { 6 }

/** A screen that refreshes itself (throttled) when live data changes. */
abstract class LiveScreen(carContext: CarContext) : Screen(carContext) {
    private val main = Handler(Looper.getMainLooper())
    private var last = 0L
    private var pending = false
    private val listener: () -> Unit = {
        val now = SystemClock.elapsedRealtime()
        if (now - last > 2000) { last = now; invalidate() }
        else if (!pending) {
            pending = true
            main.postDelayed({ pending = false; last = SystemClock.elapsedRealtime(); invalidate() }, 2000)
        }
    }

    init {
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onCreate(owner: LifecycleOwner) { DataHub.addListener(listener) }
            override fun onDestroy(owner: LifecycleOwner) {
                DataHub.removeListener(listener)
                main.removeCallbacksAndMessages(null)
            }
        })
    }
}
