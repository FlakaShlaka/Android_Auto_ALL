package com.ori.drivehub

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("drivehub", Context.MODE_PRIVATE)

    fun get(c: Context, key: String, def: String = ""): String = sp(c).getString(key, def) ?: def
    fun set(c: Context, key: String, value: String) = sp(c).edit().putString(key, value.trim()).apply()

    const val FAVOURITES = "favourites"
    const val HOME = "home"
    const val WORK = "work"
    const val STUDIO = "studio"
    const val QUICK_REPLIES = "quick_replies"

    const val DEFAULT_REPLIES = "On my way 🚗|Be there in 10 minutes|Can't talk now, I'll call you later|👍"

    fun favourites(c: Context): List<String> =
        get(c, FAVOURITES).split(",").map { it.trim() }.filter { it.isNotEmpty() }

    fun quickReplies(c: Context): List<String> =
        get(c, QUICK_REPLIES, DEFAULT_REPLIES).split("|").map { it.trim() }.filter { it.isNotEmpty() }
}
