package com.ori.drivehub.car

import android.content.Intent
import androidx.car.app.CarAppService
import androidx.car.app.Screen
import androidx.car.app.Session
import androidx.car.app.validation.HostValidator

class DriveHubCarAppService : CarAppService() {
    // Private build: accept any Android Auto host.
    override fun createHostValidator(): HostValidator = HostValidator.ALLOW_ALL_HOSTS_VALIDATOR

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun onCreateSession(): Session = DriveHubSession()
}

class DriveHubSession : Session() {
    override fun onCreateScreen(intent: Intent): Screen {
        val renderer = BrowserRenderer(carContext, lifecycle)
        return DashboardScreen(carContext, renderer)
    }
}
