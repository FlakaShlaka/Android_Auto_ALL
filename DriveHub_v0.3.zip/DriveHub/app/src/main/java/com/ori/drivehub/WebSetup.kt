package com.ori.drivehub

import android.annotation.SuppressLint
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebView

object WebSetup {
    const val YT_HOME = "https://m.youtube.com/"

    /** No playback lock of any kind: autoplay allowed, no user-gesture requirement. */
    @SuppressLint("SetJavaScriptEnabled")
    fun configure(web: WebView) {
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = false
        }
        web.webChromeClient = WebChromeClient()
    }

    const val JS_TOGGLE_PLAY =
        "(function(){var v=document.querySelector('video');if(!v)return 'none';" +
        "if(v.paused){v.play();return 'play'}v.pause();return 'pause'})()"

    /** "Enlarge": pins the video over the whole page. Tap again to restore. */
    const val JS_ENLARGE =
        "(function(){var v=document.querySelector('video');if(!v)return 'none';" +
        "if(v.dataset.dh==='1'){v.setAttribute('style',v.dataset.dhs||'');v.dataset.dh='0';return 'off'}" +
        "v.dataset.dhs=v.getAttribute('style')||'';" +
        "v.setAttribute('style','position:fixed!important;top:0!important;left:0!important;" +
        "width:100vw!important;height:100vh!important;z-index:2147483647!important;" +
        "background:#000!important;object-fit:contain!important');v.dataset.dh='1';" +
        "if(v.paused)v.play();return 'on'})()"
}
