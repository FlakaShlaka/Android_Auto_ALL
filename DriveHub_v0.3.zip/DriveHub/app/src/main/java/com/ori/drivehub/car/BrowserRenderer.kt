package com.ori.drivehub.car

import android.app.Presentation
import android.content.Context
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.ColorDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.Display
import android.view.InputDevice
import android.view.MotionEvent
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.car.app.AppManager
import androidx.car.app.CarContext
import androidx.car.app.SurfaceCallback
import androidx.car.app.SurfaceContainer
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import com.ori.drivehub.WebSetup

/**
 * Draws a real WebView (m.youtube.com) onto the Android Auto map surface.
 * The surface is wrapped in a private VirtualDisplay and a Presentation shows the WebView on it.
 * No playback lock: video plays whether the car is parked or moving.
 */
class BrowserRenderer(private val carContext: CarContext, lifecycle: Lifecycle) :
    SurfaceCallback, DefaultLifecycleObserver {

    private val main = Handler(Looper.getMainLooper())
    private var virtualDisplay: VirtualDisplay? = null
    private var presentation: WebPresentation? = null
    var currentUrl: String = WebSetup.YT_HOME
        private set

    init {
        lifecycle.addObserver(this)
        try {
            carContext.getCarService(AppManager::class.java).setSurfaceCallback(this)
        } catch (e: Exception) { Log.e(TAG, "setSurfaceCallback", e) }
    }

    override fun onSurfaceAvailable(surfaceContainer: SurfaceContainer) {
        main.post { attach(surfaceContainer) }
    }

    override fun onSurfaceDestroyed(surfaceContainer: SurfaceContainer) {
        main.post { release() }
    }

    override fun onVisibleAreaChanged(visibleArea: Rect) {}
    override fun onStableAreaChanged(stableArea: Rect) {}

    override fun onClick(x: Float, y: Float) { main.post { presentation?.tap(x, y) } }
    override fun onScroll(distanceX: Float, distanceY: Float) {
        main.post { presentation?.scroll(distanceX.toInt(), distanceY.toInt()) }
    }
    override fun onFling(velocityX: Float, velocityY: Float) {
        main.post { presentation?.scroll((-velocityX / 6).toInt(), (-velocityY / 6).toInt()) }
    }

    private fun attach(c: SurfaceContainer) {
        release()
        val surface = c.surface ?: return
        if (c.width <= 0 || c.height <= 0) return
        try {
            val dm = carContext.getSystemService(DisplayManager::class.java)
            val vd = dm.createVirtualDisplay("DriveHubBrowser", c.width, c.height, c.dpi, surface, 0)
            virtualDisplay = vd
            val p = WebPresentation(carContext.applicationContext, vd.display, currentUrl) { currentUrl = it }
            p.show()
            presentation = p
        } catch (e: Exception) {
            Log.e(TAG, "attach failed", e)
            release()
        }
    }

    private fun release() {
        try { presentation?.dismiss() } catch (_: Exception) {}
        presentation = null
        try { virtualDisplay?.release() } catch (_: Exception) {}
        virtualDisplay = null
    }

    fun load(url: String) {
        currentUrl = url
        main.post { presentation?.load(url) }
    }
    fun home() = load(WebSetup.YT_HOME)
    fun togglePlay() = main.post { presentation?.js(WebSetup.JS_TOGGLE_PLAY) }
    fun enlarge() = main.post { presentation?.js(WebSetup.JS_ENLARGE) }
    fun page(down: Boolean) = main.post { presentation?.page(down) }
    fun back() = main.post { presentation?.goBack() }

    override fun onDestroy(owner: LifecycleOwner) {
        release()
        try { carContext.getCarService(AppManager::class.java).setSurfaceCallback(null) } catch (_: Exception) {}
    }

    companion object { private const val TAG = "DriveHubBrowser" }
}

class WebPresentation(
    ctx: Context,
    display: Display,
    private val startUrl: String,
    private val onUrl: (String) -> Unit
) : Presentation(ctx, display) {

    private var web: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window?.setBackgroundDrawable(ColorDrawable(Color.BLACK))
        val w = WebView(context)
        WebSetup.configure(w)
        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) { onUrl(url) }
        }
        setContentView(w, ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        w.loadUrl(startUrl)
        web = w
    }

    override fun onStop() {
        web?.destroy()
        web = null
        super.onStop()
    }

    fun load(url: String) { web?.loadUrl(url) }
    fun js(script: String) { web?.evaluateJavascript(script, null) }
    fun goBack() { web?.let { if (it.canGoBack()) it.goBack() } }
    fun scroll(dx: Int, dy: Int) { web?.scrollBy(dx, dy) }
    fun page(down: Boolean) {
        val w = web ?: return
        val h = (w.height * 0.7f).toInt()
        w.scrollBy(0, if (down) h else -h)
    }

    fun tap(x: Float, y: Float) {
        val w = web ?: return
        val t = SystemClock.uptimeMillis()
        val down = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, x, y, 0)
        val up = MotionEvent.obtain(t, t + 60, MotionEvent.ACTION_UP, x, y, 0)
        down.source = InputDevice.SOURCE_TOUCHSCREEN
        up.source = InputDevice.SOURCE_TOUCHSCREEN
        w.dispatchTouchEvent(down)
        w.dispatchTouchEvent(up)
        down.recycle(); up.recycle()
    }
}
