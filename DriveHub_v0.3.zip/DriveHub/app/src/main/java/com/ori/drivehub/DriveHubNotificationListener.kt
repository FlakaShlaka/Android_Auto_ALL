package com.ori.drivehub

import android.app.Notification
import android.content.ComponentName
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

/** Reads WhatsApp / Teams / Maps notifications and media sessions (YouTube Music, Pocket Casts). */
class DriveHubNotificationListener : NotificationListenerService() {

    private var msm: MediaSessionManager? = null
    private val callbacks = HashMap<MediaController, MediaController.Callback>()

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> setControllers(list ?: emptyList()) }

    override fun onListenerConnected() {
        try { activeNotifications?.forEach { handle(it) } } catch (e: Exception) { Log.w(TAG, e) }
        try {
            val cn = ComponentName(this, DriveHubNotificationListener::class.java)
            msm = getSystemService(MediaSessionManager::class.java)
            msm?.addOnActiveSessionsChangedListener(sessionsListener, cn)
            setControllers(msm?.getActiveSessions(cn) ?: emptyList())
        } catch (e: Exception) { Log.w(TAG, e) }
        DataHub.changed()
    }

    override fun onListenerDisconnected() {
        try { msm?.removeOnActiveSessionsChangedListener(sessionsListener) } catch (_: Exception) {}
        setControllers(emptyList())
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        handle(sbn)
        DataHub.changed()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        if (sbn.packageName == Pk.MAPS && sbn.isOngoing) {
            DataHub.navTitle = null
            DataHub.navText = null
            DataHub.changed()
        }
    }

    private fun handle(sbn: StatusBarNotification) {
        val n = sbn.notification ?: return
        val ex = n.extras ?: return
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString()
        when (sbn.packageName) {
            Pk.WHATSAPP, Pk.WHATSAPP_BIZ -> {
                if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
                if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
                val name = ex.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString()
                    ?: title ?: return
                val last = lastMessage(ex) ?: text ?: return
                val reply = n.actions?.firstOrNull { !it.remoteInputs.isNullOrEmpty() }
                DataHub.putWhatsApp(DataHub.Chat(name, last, sbn.postTime, reply))
            }
            Pk.TEAMS -> {
                if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
                val name = title ?: return
                DataHub.putTeams(DataHub.Chat(name, text ?: "", sbn.postTime, null))
            }
            Pk.MAPS -> if (sbn.isOngoing) {
                DataHub.navTitle = title
                DataHub.navText = text
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun lastMessage(ex: Bundle): String? {
        val msgs = ex.getParcelableArray(Notification.EXTRA_MESSAGES) ?: return null
        val b = msgs.lastOrNull() as? Bundle ?: return null
        val sender = b.getCharSequence("sender")?.toString()
        val t = b.getCharSequence("text")?.toString() ?: return null
        return if (sender.isNullOrBlank()) t else "$sender: $t"
    }

    private fun setControllers(list: List<MediaController>) {
        callbacks.forEach { (c, cb) -> try { c.unregisterCallback(cb) } catch (_: Exception) {} }
        callbacks.clear()
        val main = Handler(Looper.getMainLooper())
        list.forEach { c ->
            val cb = object : MediaController.Callback() {
                override fun onMetadataChanged(metadata: android.media.MediaMetadata?) { DataHub.changed() }
                override fun onPlaybackStateChanged(state: android.media.session.PlaybackState?) { DataHub.changed() }
                override fun onQueueChanged(queue: MutableList<android.media.session.MediaSession.QueueItem>?) { DataHub.changed() }
            }
            c.registerCallback(cb, main)
            callbacks[c] = cb
        }
        DataHub.controllers = list
        DataHub.changed()
    }

    companion object { private const val TAG = "DriveHubNL" }
}
