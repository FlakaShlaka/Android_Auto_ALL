package com.ori.drivehub.car

import androidx.car.app.CarContext
import androidx.car.app.model.Action
import androidx.car.app.model.GridItem
import androidx.car.app.model.GridTemplate
import androidx.car.app.model.ItemList
import androidx.car.app.model.Template
import com.ori.drivehub.CalendarRepo
import com.ori.drivehub.DataHub
import com.ori.drivehub.Pk
import com.ori.drivehub.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** One screen, six tiles. Tap a tile to zoom into that app. */
class DashboardScreen(carContext: CarContext, private val renderer: BrowserRenderer) :
    LiveScreen(carContext) {

    override fun onGetTemplate(): Template {
        val hm = SimpleDateFormat("HH:mm", Locale.getDefault())

        val mapsText = DataHub.navTitle ?: "Tap for destinations"
        val ytmText = DataHub.nowPlaying(Pk.YT_MUSIC)?.let {
            (if (DataHub.isPlaying(Pk.YT_MUSIC)) "▶ " else "⏸ ") + it
        } ?: "Not playing"
        val waText = DataHub.recentChats().firstOrNull()?.let { "${it.name}: ${it.text}" } ?: "No new messages"
        val teamsText = CalendarRepo.upcoming(carContext, 1).firstOrNull()
            ?.let { "${hm.format(Date(it.begin))} ${it.title}" } ?: "No meetings soon"
        val pcText = DataHub.nowPlaying(Pk.POCKET_CASTS) ?: "Up Next"

        fun tile(title: String, text: String, icon: Int, onClick: () -> Unit) =
            GridItem.Builder()
                .setTitle(title)
                .setText(text.take(60))
                .setImage(carContext.icon(icon), GridItem.IMAGE_TYPE_LARGE)
                .setOnClickListener(onClick)
                .build()

        val items = ItemList.Builder()
            .addItem(tile("Maps", mapsText, R.drawable.tile_maps) {
                screenManager.push(MapsScreen(carContext)) })
            .addItem(tile("YouTube", "Browser · plays anytime", R.drawable.tile_youtube) {
                screenManager.push(BrowserScreen(carContext, renderer)) })
            .addItem(tile("YouTube Music", ytmText, R.drawable.tile_music) {
                screenManager.push(MediaScreen(carContext, Pk.YT_MUSIC, "YouTube Music")) })
            .addItem(tile("WhatsApp", waText, R.drawable.tile_whatsapp) {
                screenManager.push(WhatsAppScreen(carContext)) })
            .addItem(tile("Teams", teamsText, R.drawable.tile_teams) {
                screenManager.push(TeamsScreen(carContext)) })
            .addItem(tile("Pocket Casts", pcText, R.drawable.tile_podcasts) {
                screenManager.push(MediaScreen(carContext, Pk.POCKET_CASTS, "Pocket Casts")) })
            .build()

        return GridTemplate.Builder()
            .setTitle("DriveHub")
            .setHeaderAction(Action.APP_ICON)
            .setSingleList(items)
            .build()
    }
}
