package com.ori.drivehub.car

import android.net.Uri
import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.ItemList
import androidx.car.app.model.Row
import androidx.car.app.model.SearchTemplate
import androidx.car.app.model.Template
import androidx.car.app.navigation.model.NavigationTemplate
import com.ori.drivehub.R

/**
 * Full-screen YouTube browser on the car display.
 * Top strip: Back · Play/Pause · Enlarge · Search.  Map strip: Pan(scroll) · Up · Down · Home.
 * Taps on the video are forwarded to the web page (car API level 5+).
 */
class BrowserScreen(carContext: CarContext, private val renderer: BrowserRenderer) : Screen(carContext) {

    override fun onGetTemplate(): Template {
        fun act(title: String, onClick: () -> Unit) =
            Action.Builder().setTitle(title).setOnClickListener(onClick).build()
        fun iconAct(res: Int, onClick: () -> Unit) =
            Action.Builder().setIcon(carContext.icon(res)).setOnClickListener(onClick).build()

        val strip = ActionStrip.Builder()
            .addAction(act("Back") { renderer.back() })
            .addAction(act("Play/Pause") { renderer.togglePlay() })
            .addAction(act("Enlarge") { renderer.enlarge() })
            .addAction(act("Search") { screenManager.push(YouTubeSearchScreen(carContext, renderer)) })
            .build()

        val mapStrip = ActionStrip.Builder()
            .addAction(Action.PAN)
            .addAction(iconAct(R.drawable.ic_up) { renderer.page(false) })
            .addAction(iconAct(R.drawable.ic_down) { renderer.page(true) })
            .addAction(iconAct(R.drawable.ic_home) { screenManager.pop() })
            .build()

        return NavigationTemplate.Builder()
            .setActionStrip(strip)
            .setMapActionStrip(mapStrip)
            .setPanModeListener { }
            .build()
    }
}

class YouTubeSearchScreen(carContext: CarContext, private val renderer: BrowserRenderer) : Screen(carContext) {

    private fun go(url: String) {
        renderer.load(url)
        screenManager.pop()
    }

    override fun onGetTemplate(): Template {
        fun row(title: String, url: String) =
            Row.Builder().setTitle(title).setOnClickListener { go(url) }.build()

        val presets = ItemList.Builder()
            .addItem(row("YouTube home", "https://m.youtube.com/"))
            .addItem(row("Subscriptions", "https://m.youtube.com/feed/subscriptions"))
            .addItem(row("History / continue watching", "https://m.youtube.com/feed/history"))
            .addItem(row("Ceramics", "https://m.youtube.com/results?search_query=ceramics+wheel+throwing"))
            .build()

        return SearchTemplate.Builder(object : SearchTemplate.SearchCallback {
            override fun onSearchTextChanged(searchText: String) {}
            override fun onSearchSubmitted(searchText: String) {
                if (searchText.isNotBlank())
                    go("https://m.youtube.com/results?search_query=" + Uri.encode(searchText))
            }
        })
            .setHeaderAction(Action.BACK)
            .setSearchHint("Search YouTube")
            .setShowKeyboardByDefault(false)
            .setItemList(presets)
            .build()
    }
}
